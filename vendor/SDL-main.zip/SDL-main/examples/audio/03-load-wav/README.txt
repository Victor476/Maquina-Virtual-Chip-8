If you're running this in a web browser, you need to click the window before you'll hear anything!

This example code creates a simple audio stream for playing sound, and
loads a .wav file that is pushed through the stream in a loop.

